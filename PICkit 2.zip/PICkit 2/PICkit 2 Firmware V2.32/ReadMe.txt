PICkit 2 Firmware v2.32.00 ReadMe file

Release Notes:
v2.32.00, along with PICkit 2 Programmer software v2.52.00, PK2CMD v1.12, and
MPLAB IDE 8.15 fixes problems with simultaneous use of multiple PICkit 2 units.


DO NOT use firmware v2.32.00 with PICkit 2 Programmer software versions prior
to v2.51.00, or the Programmer-To-Go function will not work at all.
